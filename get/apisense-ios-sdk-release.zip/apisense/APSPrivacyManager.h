#import <Foundation/Foundation.h>
#import "APSPrivacyOperations.h"

/**
 *  Public class available to manager privacy settings
 */
@interface APSPrivacyManager : NSObject <APSPrivacyOperations>

@end
