#import "APSEvent.h"

@interface APSListenerCanceledEvent : APSEvent

@property (nonatomic, strong) NSString* scriptFunction;
@property (nonatomic, strong) NSString* cropID;

-(id) initWithFunction:(NSString*)function forCropID:(NSString*)cropID;

@end
