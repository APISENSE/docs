#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <UIKit/UIKit.h>

#import "APSBatteryData.h"
#import "APSStingToken.h"

#import "APSSting.h"

@protocol BatteryJsExports<JSExport>

-(NSString*) state;
-(NSString*) connector;
-(NSString*) technology;
-(id) level;
-(id) temperature;
-(id) voltage;
-(APSBatteryData*) data;

-(BOOL) isState:(int)state;
-(BOOL) isConnector:(int)connector;

-(APSStingToken*) onStateChanged:(NSString*)function;
-(APSStingToken*) onLevelChanged:(NSString*)function;

// state enum
@property (nonatomic) int FULL;
@property (nonatomic) int CHARGING;
@property (nonatomic) int DISCHARGING;

// authentication enumerated values shortcuts
@property (nonatomic) int AC;
@property (nonatomic) int USB;
@property (nonatomic) int WIRELESS;
@property (nonatomic) int NOT_CONNECTED;

@end

@interface APSBatterySting : APSSting <BatteryJsExports>

@property (nonatomic,strong) UIDevice* device;

@end