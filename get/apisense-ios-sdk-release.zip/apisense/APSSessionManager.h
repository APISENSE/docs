#import <Foundation/Foundation.h>

#import "APSCallback.h"
#import "APSClientConstants.h"
#import "APSClientUser.h"
#import "APSSession.h"
#import "APSBeeOperations.h"

#import "APSLogger.h"
#import <Objection/Objection.h>

/**
 Public class available to manage user's sessions
 */
@interface APSSessionManager : NSObject <APSBeeOperations>

/**
 Client linked at initialization
 */
@property (nonatomic,strong) APSClientUser * client;

/**
 Session manager
 */
@property (nonatomic, strong) APSSession* session;

-(void) createBeeNamed:(NSString *)fullName WithUsername:(NSString*)username WithPassword:(NSString*)password WithEmail:(NSString*)email andListener:(id<APSCallback>)listener;

-(void) loginWithEmail:(NSString*)email password:(NSString*)password andListener:(id<APSCallback>)listener;

-(void) logoutWithListener:(id<APSCallback>)listener;

-(void) getProfileWithListener:(id<APSCallback>)listener;

-(BOOL) isConnected;

@end

/**
 Login callback
 */
@interface LoginRequestCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSSessionManager *sessionManager;
@property (nonatomic, strong) id<APSCallback> listener;
-(id) initWithSessionManager:(APSSessionManager*)sessionManager andListener:(id<APSCallback>)listener;
@end

/**
 Logout callback
 */
@interface LogoutRequestCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSSessionManager *sessionManager;
@property (nonatomic, strong) id<APSCallback> listener;
-(id) initWithSessionManager:(APSSessionManager*)sessionManager andListener:(id<APSCallback>)listener;
@end