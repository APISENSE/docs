#import <Foundation/Foundation.h>

#import "Crop.h"

#import <Mantle/Mantle.h>

@interface APSCrop : MTLModel <MTLJSONSerializing>

@property (nonatomic, strong) NSString* location;
@property (nonatomic, strong) NSString* name;
@property (nonatomic, strong) NSString* owner;
@property int version;
@property (nonatomic, strong) NSString* shortDescription;
@property (nonatomic, strong) NSString* longDescription;
@property long begin;
@property long end;

-(id) initWithCrop:(Crop*) crop;
@end