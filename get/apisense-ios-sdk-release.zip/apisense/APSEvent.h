#import <Foundation/Foundation.h>

@interface APSEvent : NSObject

@property (nonatomic, strong) NSString* timestamp;

-(NSString*) buildDateWith8601Format;

@end
