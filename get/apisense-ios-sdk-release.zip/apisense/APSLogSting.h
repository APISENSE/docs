#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>

#import "APSSting.h"

@protocol LogJsExports<JSExport>
- (void) info:(NSString *)message;
- (void) debug:(NSString *)message;
- (void) error:(NSString *)message;
@end

@interface APSLogSting : APSSting <LogJsExports>
@end