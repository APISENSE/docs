#import <Foundation/Foundation.h>

#import "APSData.h"
#import "APSEvent.h"

@interface APSListenerTriggeredEvent : APSEvent

@property (nonatomic, strong) APSData* data;
@property (nonatomic, strong) NSString* cropId;
@property (nonatomic, strong) NSString* notificationName;

-(id) initWithData:(APSData*)data forCropId:(NSString*)cropId withNotificationName:(NSString*)name;

@end
