#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSExecutionHandler.h"

@interface APSExecutionHandlerFactory : NSObject

@property (nonatomic, strong) APSStingManager* stingManager;
-(APSExecutionHandler*) getHandler;

@end
