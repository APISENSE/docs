#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import <tolo/Tolo.h>

#import "APSSting.h"
#import "APSListenerCanceledEvent.h"

@class APSSting;

@protocol TokenJsExports<JSExport>
-(void) cancel;
@end

@interface APSStingToken : NSObject<TokenJsExports>

-(id) initWithSting:(APSSting *)sting withEventName:(NSString*)eventName andFunction:(NSString*)function;

@property (nonatomic, strong) APSSting* targetSting;
@property (nonatomic, strong) NSString* targetFunction;
@property (nonatomic, strong) NSString* eventName;

@end