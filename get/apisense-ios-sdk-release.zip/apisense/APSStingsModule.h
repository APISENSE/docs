#import <Foundation/Foundation.h>

#import "JSObjectionModule.h"
#import "APSStings.h"

@interface APSStingsModule : JSObjectionModule

@end
