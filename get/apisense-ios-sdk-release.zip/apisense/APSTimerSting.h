#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <UIKit/UIKit.h>

#import "APSSting.h"
#import "APSTimerData.h"

@protocol TimerJsExports<JSExport>
-(APSStingToken*) every:(NSString*)timePeriod :(NSString*)function;
-(APSStingToken*) at:(NSString*)hour :(NSString*)function;
-(APSStingToken*) once:(NSString*)hour :(NSString*)function;
@end

@interface APSTimerSting : APSSting<TimerJsExports>

@end
