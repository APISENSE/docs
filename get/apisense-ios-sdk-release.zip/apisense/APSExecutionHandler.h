#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <tolo/Tolo.h>

#import "APSScriptLibrary.h"
#import "APSStingOperations.h"
#import "APSListenerTriggeredEvent.h"
#import "APSListenerAddedEvent.h"
#import "APSListenerCanceledEvent.h"
#import "APSScriptHandler.h"
#import "APSCallback.h"
#import "APSStingManager.h"
#import "APSLogger.h"

@interface APSExecutionHandler : NSObject

@property (nonatomic, strong) APSStingManager* stingManager;
@property (nonatomic,strong) JSContext* executionContext;
@property (nonatomic, strong) NSMutableArray* stings;
@property (nonatomic) BOOL isRunning;
@property (nonatomic, strong) NSString* location;
@property (nonatomic, strong) NSString* script;

@property (nonatomic, strong) NSMutableArray* scriptHandlerArray;

-(void) start:(NSString*)location andScript:(NSString*)script withListener:(id<APSCallback>)listener;
-(void) stop;

@end
