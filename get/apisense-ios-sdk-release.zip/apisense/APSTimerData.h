#import "APSData.h"

@interface APSTimerData : APSData

@end
