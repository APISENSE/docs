#import <Foundation/Foundation.h>

@interface APSSensor : NSObject

/**
 *  Sensor's name to display
 */
@property (nonatomic, strong) NSString* name;

/**
 *  Sting associated to the sensor
 */
@property (nonatomic, strong) NSString* stingName;

/**
 *  Path to the sensor's image
 */
@property (nonatomic, strong) NSString* icon;

/**
 *  Sensor's description
 */
@property (nonatomic, strong) NSString* desc;

/**
 *  Create a new sensor
 *
 *  @param name      <#name description#>
 *  @param stingName <#stingName description#>
 *  @param icon      <#icon description#>
 *  @param desc      <#desc description#>
 *
 *  @return <#return value description#>
 */
-(id) initWithName:(NSString*)name stingName:(NSString*)stingName icon:(NSString*)icon desc:(NSString*)desc;

@end
