#import <Foundation/Foundation.h>

#import "APSCrop.h"
#import "APSCallback.h"
#import "APSSubscribedCrop.h"
#import "APSPersistedCrop.h"
#import "APSClient.h"
#import "Crop.h"

/**
 *  Proxy used by APSCropManager
 */
@interface APSClientCrop : APSClient

-(void) subscribeTo:(APSCrop*)crop withToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
-(void) retrieveSubscribedCropAt:(NSString*)url withToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
-(void) unsubscribeTo:(APSSubscribedCrop*)crop withToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
-(void) getSubscriptionsWithToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
@end