#import <Foundation/Foundation.h>
#import "APSPreferencesOperations.h"
#import "APSSession.h"
#import "APSClientPreferences.h"
#import "APSCropManager.h"
#import "APSLogger.h"
#import "APSPreferences.h"
#import "APSSensor.h"

#import <Objection/Objection.h>

/**
 *  Public class available to manager privacy settings
 */
@interface APSPreferencesManager : NSObject <APSPreferencesOperations>
@property (nonatomic, strong) APSSession* session;
@property (nonatomic, strong) APSClientPreferences* clientPreferences;
@property (nonatomic, strong) APSCropManager* cropManager;

-(void) retrievePreferencesWithListener:(id<APSCallback>)listener;
-(void) savePreferences:(APSPreferences*)preferences withListener:(id<APSCallback>)listener;
-(NSArray*) retrieveAvailableSensors;
-(APSSensor*) retrieveSensorForStingName:(NSString*)name;
@end

@interface APSRetrievePrivacyPreferencesCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSPreferencesManager* manager;
-(id) initWithManager:(APSPreferencesManager*)manager andListener:(id<APSCallback>)listener;
@end

@interface APSSavePrivacyPreferencesCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSPreferences* preferences;
@property (nonatomic, strong) APSPreferencesManager* manager;
-(id) initWithPreferences:(APSPreferences*)preferences manager:(APSPreferencesManager*)manager andListener:(id<APSCallback>)listener;
@end