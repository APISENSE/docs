#import "APSSting.h"
#import "APSPage.h"
#import "APSFormOperations.h"
#import "APSFormData.h"

#import <QuickDialog/QuickDialog.h>
#import "APSImagePickerElement.h"
#import "APSVideoPickerElement.h"
#import "APSAudioPickerElement.h"

@class APSPage;

@protocol PageJsExports<JSExport>
-(void) show;
-(APSPage*) checkbox:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(JSValue*)values;
-(APSPage*) datepicker:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSPage*) radiobutton:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(JSValue*)values;
-(APSPage*) textarea:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSPage*) textfield:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSPage*) numberfield:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSPage*) label:(NSString*)label;
-(APSPage*) section:(NSString*)title;
-(APSPage*) picture:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSPage*) video:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(NSString*)duration;
-(APSPage*) sound:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(NSString*)duration;
@end

@interface APSPage : APSSting<PageJsExports, APSFormOperations, UINavigationControllerDelegate>
@property (nonatomic, strong) APSPage* nextPage;
-(id) initWithTitle:(NSString*)title forCrop:(NSString*)cropID;
@end
