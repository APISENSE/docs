#import "APSData.h"

@protocol NetworkDataExports<JSExport>
@property id url;
@property id ping;
@property id traceroute;
@property id ttl;
@end

@interface APSNetworkData : APSData<NetworkDataExports>
@end