#import <CoreLocation/CoreLocation.h>

#import "APSData.h"

@protocol LocationDataExports<JSExport>

@property (nonatomic, strong) NSString* mode;
@property (nonatomic, strong) NSString* source;
@property (nonatomic, strong) id latitude;
@property (nonatomic, strong) id longitude;
@property (nonatomic, strong) id accuracy;
@property (nonatomic, strong) id speed;
@property (nonatomic, strong) id altitude;
@property (nonatomic, strong) id bearing;

@end

@interface APSLocationData : APSData<LocationDataExports>

-(id) initWithMode:(NSString*)_mode source:(NSString*)_source latitude:(id)_latitude longitude:(id)_longitude accuracy:(id)_accuracy speed:(id)_speed altitude:(id)_altitude bearing:(id)_bearing;
-(id) initWithLocation:(CLLocation*)location;

@end
