#import "APSSting.h"
#import "APSFormSting.h"
#import "APSPage.h"
#import "APSMultiPage.h"
#import "APSSinglePage.h"

@protocol FormJsExports<JSExport>
-(APSSinglePage*) singlePage:(NSString*)title;
-(APSMultiPage*) multiPage;
-(void) onResult:(NSString*)function;
@end

@interface APSFormSting : APSSting<FormJsExports>

@end
