#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import <Mantle/Mantle.h>

@protocol DataExports<JSExport>
@property (nonatomic) long timestamp;
@end

@interface APSData : MTLModel<MTLJSONSerializing, DataExports>
@end