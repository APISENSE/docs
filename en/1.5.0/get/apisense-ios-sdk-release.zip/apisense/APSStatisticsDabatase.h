#import "APSDatabase.h"
#import "Statistic.h"
#import "APSUploadedEntry.h"
#import "APSCropUsageStatistics.h"

@interface APSStatisticsDabatase : APSDatabase
-(APSCropUsageStatistics*) retrieveCropUsage:(NSString*)slug;
-(BOOL) add:(NSString*)slug;
-(void) update:(APSCropUsageStatistics*)cropUsage;
-(BOOL) delete:(NSString*)slug;
@end