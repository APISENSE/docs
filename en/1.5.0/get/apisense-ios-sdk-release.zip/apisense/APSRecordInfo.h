#import <Foundation/Foundation.h>

/**
 *  Handle information used to upload a data
 */
@interface APSRecordInfo : NSObject

@property (nonatomic, strong) NSString* collectUrl;
@property (nonatomic) int version;

@end
