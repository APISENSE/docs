#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSStingsModule.h"
#import "APSStings.h"
#import "APSStingOperations.h"

@interface APSScriptLibrary : NSObject

/**
 *  Injector responsible to inject stings at script runtime
 */
@property (nonatomic,strong) JSObjectionInjector* INJECTOR;

/**
 *  Default stings mapping
 */
extern NSDictionary* defaultStingsMapping;

/**
 *  Link a keywork to the associated facade
 */
@property (nonatomic, strong) NSMutableDictionary* stingsMapping;

/**
 *  Retrieve the Facade associated to the name
 *
 *  @param name Name of the facade
 *
 *  @return the Facade class
 */
+ (APSSting<APSStingOperations> *) getSting:(NSString*)name;

/**
 *  Initialize the default stings map linking a keywork to its implementation
 *  @note "log" -> [JsLogFacade class]
 */
+ (void) initStingsMap;

/**
 *  Initialize the default injector with default binding
 */
+ (void) initInjector;

/**
 *  Extend the default injector with a new one
 *
 *  @param injector The new JSObjectionModule to provide
 */
+ (void) setInjector:(JSObjectionInjector*) injector;

/**
 *  Retrieve current injector
 *
 *  @return The injector used
 */
+ (JSObjectionInjector*) getInjector;

/**
 *  Add custom mapping for extra stings
 
 *  @note "name" -> [JsNameFacade class]
 *  @param dic The new mapping
 */
+ (void) addStingsMapping:(NSDictionary*)dic;

/**
 *  Retrieve the current mapping
 *
 *  @return Map association between name and classes
 */
+ (NSDictionary*) getStingsMapping;

@end
