#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

#import "Crop.h"
#import "APSExecutionHandler.h"
#import "APSScriptLibrary.h"

/**
 *  Represents minimal information you get once you subscribed to a crop
 */
@interface APSSubscribedCrop : MTLModel <MTLJSONSerializing>

/**
 *  Script used by the crop
 */
@property (nonatomic, strong) NSString* script;

/**
 *  URL where are sent data collected
 */
@property (nonatomic, strong) NSString* collectUrl;

/**
 *  Crop's subscription location on the Hive server
 */
@property (nonatomic, strong) NSString* location;

/**
 * Crop's dataToken used to upload data on Honeycomb serv
 */
@property (nonatomic, strong) NSString* dataToken;

/**
 *  Create a SubscribedCrop with a Crop
 *  @param crop from database
 */
-(id) initWithCrop:(Crop*) crop;

@end
