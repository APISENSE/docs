#import "APSCrop.h"

@protocol APSStatisticsOperations
-(APSCropUsageStatistics*) getCropUsage:(APSCrop*)crop;
@end