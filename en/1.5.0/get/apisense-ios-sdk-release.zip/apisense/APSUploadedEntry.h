#import <Foundation/Foundation.h>

@interface APSUploadedEntry : NSObject<NSCoding>
@property (nonatomic, strong) NSNumber* numberOfTraces;
@property (nonatomic, strong) NSDate* date;
-(id) initWithNumberOfTraces:(NSNumber*)number andDate:(NSDate*)date;
@end