#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <UIKit/UIKit.h>

#import "APSBatteryData.h"
#import "APSStingToken.h"

#import "APSSting.h"

#define STING_NAME @"Battery"
#define STING_DESC @"Retrieve information about the device battery status"

@protocol BatteryJsExports<JSExport>

/**
 *  Current state of the device battery
 *
 *  @return Current state
 */
-(NSString*) state;

/**
 *  Type of connector is currently used by the device
 *
 *  @return Connector used
 */
-(NSString*) connector;

/**
 *  Technology is used by the device
 *
 *  @return Technology used
 */
-(NSString*) technology;

/**
 *  Current battery charge level in percent
 *
 *  @return Battery level
 */
-(id) level;

/**
 *  Current battery temperature in degree celcius
 *
 *  @return Battery temperature
 */
-(id) temperature;

/**
 *  Current battery voltage in Volt
 *
 *  @return Battery voltage
 */
-(id) voltage;

/**
 *  JSON object describing the battery
 *
 *  @return JSON object
 */
-(APSBatteryData*) data;

/**
 *  Check if the battery is in a specific state
 *
 *  @param state to check
 *
 *  @return true if it is, false otherwise
 */
-(BOOL) isState:(int)state;

/**
 *  Check the type of battery connector
 *
 *  @param connector to check
 *
 *  @return true if it is, false otherwise
 */
-(BOOL) isConnector:(int)connector;

/**
 *  Event listener on the battery state
 *
 *  @param function Callback function executed when event triggered
 *
 *  @return StingToken
 */
-(APSStingToken*) onStateChanged:(NSString*)function;

/**
 *  Event listener on the battery level
 *
 *  @param function Callback function executed when event triggered
 *
 *  @return StingToken
 */
-(APSStingToken*) onLevelChanged:(NSString*)function;

/**
 *  Constant representing the battery fully charged
 */
@property (nonatomic) int FULL;

/**
 *  Constant representing the battery currently charging
 */
@property (nonatomic) int CHARGING;

/**
 *  Constant representing the battery currently discharging
 */
@property (nonatomic) int DISCHARGING;

/**
 *  Constant representing the device plugged to AC
 */
@property (nonatomic) int AC;

/**
 *  Constant representing the device plugged to USB
 */
@property (nonatomic) int USB;

/**
 *  Constant representing the device charging through wireless
 */
@property (nonatomic) int WIRELESS;

/**
 *  Constant representing the device not connected to anything
 */
@property (nonatomic) int NOT_CONNECTED;

@end

@interface APSBatterySting : APSSting <BatteryJsExports>

@property (nonatomic,strong) UIDevice* device;

@end