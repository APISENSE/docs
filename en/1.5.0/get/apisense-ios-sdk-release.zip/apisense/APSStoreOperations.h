@protocol APSStoreOperations

/**
 *  Retrieve all crops available on the store
 *
 *  @param listener Implements APSCallback class, returns NSArray of APSCrop on success
 */
- (void) findAllCropsWithListener:(id<APSCallback>)listener;

/**
 *  Retrieve all crop runnable crops on the store using enabledStings
 *
 *  @param listener Implements APSCallback class, returns NSArray of APSCrop on success
 */
- (void) findAllRunnableCropsWithListener:(id<APSCallback>)listener;

/**
 *  Retrieve ONE crop matching the cropID
 *
 *  @param cropID   The crop ID matching the crop to get
 *  @param listener Implements APSCallback class, returns an APSCrop on success
 */
- (void) findSpecificCrop:(NSString*)cropID andListener:(id<APSCallback>)listener; // Crop

@end