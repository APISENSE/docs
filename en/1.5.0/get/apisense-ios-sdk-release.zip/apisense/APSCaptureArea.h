#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@interface APSCaptureArea : MTLModel <MTLJSONSerializing>

/**
 *  Latitude of the capture area
 */
@property (nonatomic, strong) NSNumber* latitude;

/**
 *  Longitude of the capture area
 */
@property (nonatomic, strong) NSNumber* longitude;

/**
 *  Radius in Kms
 */
@property (nonatomic, strong) NSNumber* radius;

@end
