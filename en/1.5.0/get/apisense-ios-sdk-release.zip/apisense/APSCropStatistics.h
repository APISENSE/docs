#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@interface APSCropStatistics : MTLModel <MTLJSONSerializing>
@property (nonatomic, strong) NSNumber* numberOfSubscribers;
@property (nonatomic, strong) NSNumber* numberOfEntries;
@property (nonatomic, strong) NSNumber* size;
@property (nonatomic, strong) NSString* cropCreation;
@property (nonatomic, strong) NSString* createdAt;
@property (nonatomic, strong) NSString* updatedAt;
@end
