#import <Foundation/Foundation.h>

#import "APSDatabase.h"
#import "APSSensor.h"

/**
 Default hive url
 */
extern NSString* HIVE_BASE_URL;

/**
 Default crops database table name
 */
extern NSString *const CROPS_TABLE_NAME;

/**
 Default subscribed crops database table name
 */
extern NSString *const SUBSCRIBED_CROPS_TABLE_NAME;

/**
 *  Default database name
 */
extern NSString* const DB_NAME;

/**
 * Stings supported by the SDK
 */
extern NSArray* availableStings;

