#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#import "APSStingToken.h"
#import "APSLocationData.h"
#import "APSSting.h"

@protocol LocationJsExports<JSExport>

// source enumerated values shortcuts
@property (nonatomic) int UNKNOWN;
@property (nonatomic) int GPS;
@property (nonatomic) int NETWORK;

// mode enumerated values shortcuts
@property (nonatomic) int ACTIVE;
@property (nonatomic) int PASSIVE;

-(BOOL) isMode:(int)mode;
-(BOOL) isSource:(int)source;

-(NSString*) mode;
-(NSString*) source;
-(id) latitude;
-(id) longitude;
-(id) accuracy;
-(id) speed;
-(id) altitude;
-(id) bearing;

-(APSLocationData*) data;
-(APSStingToken*) onLocationChanged:(id)parameters :(NSString*)function;

@end

@interface APSLocationSting : APSSting <CLLocationManagerDelegate, LocationJsExports>

@property (nonatomic, strong) CLLocationManager* locationManager;
@property (strong, nonatomic) CLLocation *lastLocation;

@property (nonatomic, strong) id state;
@property (nonatomic) BOOL isRunning;
@end