#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

#import "APSCrop.h"

@interface APSSubscription : MTLModel <MTLJSONSerializing>
@property (nonatomic, strong) NSString* subscriptionUrl;
@property (nonatomic, strong) NSString* dataToken;
@property (nonatomic, strong) NSString* cropLocation;
@end
