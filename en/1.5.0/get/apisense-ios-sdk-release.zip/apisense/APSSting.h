#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "APSStingOperations.h"
#import "APSListenerTriggeredEvent.h"
#import "APSEventBus.h"
#import "APSListenerAddedEvent.h"
#import "APSStingToken.h"

@class APSStingToken;

@interface APSSting : NSObject <APSStingOperations>

@property (nonatomic, strong) NSString* cropID;
@property (nonatomic, strong) NSMutableArray* listeners;
@property (nonatomic, strong) APSEventBus* bus;
@property (nonatomic, strong) NSMutableDictionary* notificationsCountMap;
@property (nonatomic, strong) NSMutableDictionary* eventToNotification;

- (APSStingToken*) registerEvent:(NSString*)eventName withFunction:(NSString*)function;
- (void) unregisterEvent:(NSString*)eventName;
- (void) stopEvent:(NSString*)eventName;

@property (nonatomic) int UNKNOWN;

@end
