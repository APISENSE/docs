#import "APSCallback.h"
#import "APSPreferences.h"

@protocol APSPreferencesOperations

/**
 *  Retrieve user's Preferences, user must be connected
 *
 *  @param listener Callback when completed, returns APSPreferences
 */
-(void) retrievePreferencesWithListener:(id<APSCallback>)listener;

/**
 *  Save user's preferences
 *
 *  @param preferences new user's preferences
 *  @param listener    callback when completed, returns nil
 */
-(void) savePreferences:(APSPreferences*)preferences withListener:(id<APSCallback>)listener;

/**
 *  Retrieve SDK available sensors
 *
 *  @return NSArray of APSSensor available
 */
-(NSArray*) retrieveAvailableSensors;

/**
 *  Retrieve sensor associated to sting name
 *
 *  @param name The sting considered
 *
 *  @return APSSensor if found, undefined sensor if not
 */
-(APSSensor*) retrieveSensorForStingName:(NSString*)name;

@end