#import "APSCommonForm.h"

@class APSSinglePage;

@protocol SinglePageJsExports<JSExport>
-(APSSinglePage*) next:(NSString*)title;
-(APSSinglePage*) checkbox:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(JSValue*)values;
-(APSSinglePage*) datepicker:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSSinglePage*) radiobutton:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(JSValue*)values;
-(APSSinglePage*) textarea:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSSinglePage*) textfield:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSSinglePage*) numberfield:(NSString*)label :(NSString*)identifier :(BOOL)mandatory;
-(APSSinglePage*) label:(NSString*)label;
@end

@interface APSSinglePage : APSCommonForm<SinglePageJsExports>
-(id) initWithTitle:(NSString*)title forCrop:(NSString*)cropID;
@end
