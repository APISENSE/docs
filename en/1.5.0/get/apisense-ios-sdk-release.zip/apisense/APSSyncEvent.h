#import "APSData.h"
#import "APSEvent.h"

@interface APSSyncEvent : APSEvent

@property (nonatomic, strong) NSString* cropID;
@property (nonatomic, strong) NSDictionary* header;

@end