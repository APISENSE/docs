#import <Foundation/Foundation.h>
#import "APSPage.h"

@protocol CommonFormJsExports<JSExport>
-(void) show;
@end

@interface APSCommonForm : NSObject<CommonFormJsExports>
@property (nonatomic, strong) NSArray* pages;
@property (nonatomic, strong) NSString* cropID;
-(id) initForCrop:(NSString*)cropID;
@end
