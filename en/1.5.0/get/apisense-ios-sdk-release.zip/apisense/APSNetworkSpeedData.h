#import "APSData.h"

@protocol NetworkSpeedDataExports<JSExport>
@property id url;
@property id speed;
@property id time;
@property id size;
@end

@interface APSNetworkSpeedData : APSData<NetworkSpeedDataExports>
@end