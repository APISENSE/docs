#import "APSData.h"

@protocol FormDataExports<JSExport>
@property (nonatomic, strong) NSDictionary* result;
@end


@interface APSFormData : APSData<FormDataExports>
-(id) initWithResult:(NSDictionary*)_result;
@end
