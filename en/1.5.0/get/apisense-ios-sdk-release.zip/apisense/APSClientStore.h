#import <Foundation/Foundation.h>

#import "APSClient.h"
#import "APSCallback.h"
#import "APSSession.h"

@interface APSClientStore : APSClient
- (void) findAllCropsWithToken:(NSString*)userToken accessKey:(NSString*)key andListener:(id<APSCallback>)listener;
- (void) findAllCropsWithToken:(NSString*)userToken forStings:(NSArray*)enabledStings accessKey:(NSString*)key andListener:(id<APSCallback>)listener;
- (void) fetchSingleCropWithToken:(NSString*)userToken accessKey:(NSString*)key location:(NSString*)location andListener:(id<APSCallback>)listener;
@end
