#import "APSCommonForm.h"

@protocol MultiPageJsExports<JSExport>
-(void) set:(JSValue*)pages;
-(APSPage*) page:(NSString*)title;
@end

@interface APSMultiPage : APSCommonForm<MultiPageJsExports>
@end
