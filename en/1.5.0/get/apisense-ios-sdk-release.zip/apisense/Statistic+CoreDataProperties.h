//
//  Statistic+CoreDataProperties.h
//  
//
//  Created by Spirals on 17/11/2015.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Statistic.h"

NS_ASSUME_NONNULL_BEGIN

@interface Statistic (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *slug;
@property (nullable, nonatomic, retain) NSData *uploaded;
@property (nullable, nonatomic, retain) NSNumber *toUpload;
@property (nullable, nonatomic, retain) NSNumber *totalUploaded;

@end

NS_ASSUME_NONNULL_END
