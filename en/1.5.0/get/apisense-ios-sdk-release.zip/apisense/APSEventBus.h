#import <Foundation/Foundation.h>
#import <tolo/Tolo.h>
#import "APSEvent.h"
#import "APSLogger.h"

@interface APSEventBus : NSObject

-(void) publish:(APSEvent*)event;

@end
