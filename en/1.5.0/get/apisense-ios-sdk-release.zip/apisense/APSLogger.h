#import <Foundation/Foundation.h>
#import <CocoaLumberjack/CocoaLumberjack.h>

/**
 * Enable or disable SDK Debug log
 */
#define DEBUG_ENABLED NO

/**
 *  Log level required, shouldn't be changed
 */
static const DDLogLevel ddLogLevel = DDLogLevelAll;

/**
 *  Logger interface
 */
@interface APSLogger : NSObject <DDLogFormatter> {
    int loggerCount;
    NSDateFormatter *threadUnsafeDateFormatter;
}
@end
