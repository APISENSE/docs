#import <Foundation/Foundation.h>

#import "APSRecordInfo.h"
#import "Record.h"

/**
 Contains all information we need to save about a data
 */
@interface APSRecord : NSObject

-(id) initWithRecord:(Record*)record;
-(id) initWithRecordInfo:(APSRecordInfo*)record andData:(NSDictionary*)data withTimestamp:(NSString*)timestamp forCropID:(NSString*)cropId;
-(NSMutableDictionary*) buildPropertiesDictionary;

@property (nonatomic, strong) NSString* cropId;
@property (nonatomic, strong) NSString* collectUrl;
@property (nonatomic) int version;
@property (nonatomic, strong) NSString* timestamp;
@property (nonatomic, strong) NSString* data;

@end
