#import <Foundation/Foundation.h>

#import "APSDatabase.h"
#import "APSRecord.h"
#import "Record.h"

/**
 *  Handle Record modification in local database
 */
@interface APSRecordDatabase : APSDatabase

-(BOOL) save:(APSRecord*)record;
-(NSArray*) retrieveAll;
-(NSArray*) retrieveAllForID:(NSString*)cropID;
-(BOOL) deleteAllForID:(NSString*)cropID;
-(void) deleteAllForUrl:(NSString*)url andVersion:(NSString*)version;
-(NSArray*) getAvailableIds;

@end
