#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <AFNetworking/AFNetworking.h>
#import <FTPManager/FTPManager.h>

#import "IVYTraceroute.h"

#import "APSSting.h"
#import "APSNetworkData.h"
#import "APSNetworkSpeedData.h"

@protocol NetworkJsExports<JSExport>
- (void) onScanCompleted:(NSString*)url :(NSString*)function;
- (void) onDownloadCompleted:(NSString*)url :(NSString*)function;
- (void) onUploadCompleted:(NSString*)protocol :(NSString*)url :(NSString*)username :(NSString*)password :(int)Mo :(NSString*)function;
@end

@interface APSAPMSting : APSSting <NetworkJsExports>
@property (nonatomic, strong) FTPManager* FTPManager;
@end