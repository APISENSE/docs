@protocol APSStingOperations

/**
 *  Start running the manager associated to the sensor
 */
-(void) start;

/**
 *  Stop the manager associated to the sensor
 */
-(void) stop;

@end