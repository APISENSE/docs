#import <Foundation/Foundation.h>
#import <Objection/Objection.h>
#import "APSStatisticsDabatase.h"
#import "APSStatisticsOperations.h"
#import "APSCrop.h"

@interface APSStatisticsManager : NSObject<APSStatisticsOperations>
@property (nonatomic, strong) APSStatisticsDabatase* statisticsDatabase;
-(APSCropUsageStatistics*) getCropUsage:(APSCrop*)crop;
@end
