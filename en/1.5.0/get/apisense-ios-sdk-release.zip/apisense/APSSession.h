#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSUserDefaultsManager.h"

/**
 *  Handle user's connexion status
 */
@interface APSSession : NSObject

/**
 Token retrieved when the user is connected
 */
@property (nonatomic,strong) NSString* userToken;

/**
 *  Access key to see owner's key private crops
 */
@property (nonatomic, strong) NSString* accessKey;

/**
 Check if the user connected
 @return YES if connected, NO otherwise
 */
-(BOOL) isConnected;

/**
 Delete the current token value
 */
-(void) clearToken;

@end
