#import "APSListenerTriggeredEvent.h"

@interface APSListenerAddedEvent : APSEvent

@property (nonatomic, strong) NSString* notificationName;
@property (nonatomic, strong) NSString* scriptFunction;
@property (nonatomic, strong) NSString* cropID;

-(id) initWithScript:(NSString*)script andNotificationName:(NSString*)name forCropID:(NSString*)cropID;
@end
