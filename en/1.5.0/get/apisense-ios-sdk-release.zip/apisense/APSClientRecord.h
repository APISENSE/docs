#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSClient.h"
#import "APSRecordDatabase.h"

/**
 *  Handle communication with Honeycomb server
 */
@interface APSClientRecord : APSClient

@property (nonatomic,strong) APSRecordDatabase* recordDatabase;

-(void) exportTo:(NSURL*)url data:(NSString*)data dataToken:(NSString*)token withListener:(id<APSCallback>)listener;
-(void) exportTo:(NSURL*)url mediaPath:(NSString*)fullPath mediaID:(NSString*)mediaID dataToken:token withListener:(id<APSCallback>)listener;

@end