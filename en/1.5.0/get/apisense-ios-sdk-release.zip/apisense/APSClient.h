#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSCallback.h"
#import "APSClientConstants.h"
#import "APSClientOperations.h"
#import "APSLogger.h"
#import "APSUserDefaultsManager.h"

#import <AFNetworking/AFNetworking.h>

/**
 HTTP class based on AFNetworking used to send REST requests
 */
@interface APSClient : NSObject <APSClientOperations>

/**
 Object used to make REST request
 */
@property (nonatomic, strong) AFHTTPRequestOperationManager* manager;

/**
 Default Hive URL
 */
@property (nonatomic, strong) NSURL *baseURL;

@property (nonatomic, strong) AFHTTPRequestSerializer <AFURLRequestSerialization> *requestSerializer;
@property (nonatomic, strong) APSUserDefaultsManager* preferences;
@property (nonatomic, strong) NSString* sdkKey;

#pragma Methods

- (void)executeBasicPostRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;
- (void)executePostRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;
- (void)executeGetRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;
- (void)executePutRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;
- (void)executeDeleteRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;

- (void)executePostRequest:(NSURL *)request fileUrl:(NSURL*)url fileName:(NSString*)name andListener:(id<APSCallback>)listener;

- (void)executeHoneycombPostRequest:(NSURL*)url withData:(NSDictionary*)data dataToken:(NSString*)token andListener:(id<APSCallback>)listener;

#pragma Private methods

/**
 Build a NSURL object based
 @param url
 		The url to build
 */
-(NSURL*) generateHiveRequestWithURLParameters:(NSString*) url;

/**
 Build a NSURL object based and set the userToken
 @param url
		The url to build
 @param userToken
 		The userToken to set as a header
 */
-(NSURL*) generateHiveRequestWithURLParameters:(NSString*) url andToken:(NSString*)userToken;

-(NSURL*) generateHiveRequestWithURLParameters:(NSString*) url key:(NSString*)key andToken:(NSString*)userToken;


/**
 Generate the full REST request URL and set the header "token" to nil
 @param url
        baseUrl where to send the request
 @param urlParameters
        The post baseURL string
 */
-(NSURL*) generateHoneycombRequestWithURL:(NSString*)url andVersion:(NSString*)urlParameters;

/**
 *  Reset the default serializer used to contact hive or honeycomb server. Called after each request to avoid conflict between content type headers
 */
-(void) resetRequestSerializer;

@end