#import <Foundation/Foundation.h>

#import "APSCrop.h"
#import "APSClientCrop.h"
#import "APSSession.h"
#import "APSCropDatabase.h"
#import "APSStatisticsDabatase.h"

#import "APSCallback.h"
#import "APSClientConstants.h"

#import "APSCropOperations.h"
#import "APSExecutionHandler.h"
#import "APSExecutionHandlerFactory.h"
#import "APSLogger.h"
#import "APSUserDefaultsManager.h"
#import "APSSubscription.h"
#import "APSClientStore.h"
#import "APSPreferences.h"

#import <tolo/Tolo.h>
#import <Objection/Objection.h>
#import <Mantle/Mantle.h>

/**
 Public class available to manage crops installed on the device
 */
@interface APSCropManager : NSObject <APSCropOperations>

@property (nonatomic,strong) APSClientCrop * client;
@property (nonatomic, strong) APSSession* session;
@property (nonatomic, strong) APSCropDatabase* cropDatabase;
@property (nonatomic, strong) APSStatisticsDabatase* statisticsDatabase;
@property (nonatomic, strong) APSClientStore* clientStore;
@property (nonatomic, strong) APSExecutionHandlerFactory* executionHandlerFactory;

-(void) subscribeTo:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) unsubscribeTo:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) start:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) stop:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) update:(NSString*)cropLocation withListener:(id<APSCallback>)listener;
-(void) getSubscriptionsWithListener:(id<APSCallback>)listener;
-(void) synchroniseSubscriptionsWithListener:(id<APSCallback>)listener;
-(void) restartActiveCrops;
-(void) restart:(APSCrop*)crop;
-(void) updateCropsState:(APSPreferences*)preferences;
-(BOOL) canBeRunning:(APSCrop*)crop withPreferences:(APSPreferences*)preferences;
-(BOOL) isSubscribed:(APSCrop*)crop;
-(BOOL) isRunning:(APSCrop*)crop;
-(void) installSpecific:(NSString*)slug withListener:(id<APSCallback>)listener;
@end

#pragma install specific crop
@interface APSInstallSpecificCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) id<APSCallback> listener;
-(id) initWithManager:(APSCropManager*)manager andListener:(id<APSCallback>)listener;
@end

#pragma restart specific crop
@interface APSRestartSingleCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSCrop* crop;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithCrop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end

#pragma update callbacks declaration

@interface APSFetchSingleCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithListener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

@interface APSFetchLocalSubscribedCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithCrop:(APSCrop*)crop listener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

@interface APSFetchRemoteSubscribedCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
@property (nonatomic, strong) APSSubscribedCrop* localeSubCrop;
-(id) initWithCrop:(APSCrop*)crop localeSubCrop:(APSSubscribedCrop*)subCrop listener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

# pragma subscribeTo callbacks declaration

@interface RequestSubscriptionUrlCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithListener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

@interface RetrieveSubscriptionCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithListener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

# pragma unsubscribeTo callbacks declaration

@interface RetrieveCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithListener:(id<APSCallback>)listener withCrop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end

@interface UnsubscriptionCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithListener:(id<APSCallback>)listener crop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end

@interface DeleteCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithCrop:(APSCrop*)crop listener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

@interface StopCallback : NSObject <APSCallback>
@end

# pragma start callback declaration

@interface RetrieveCropScriptCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithListener:(id<APSCallback>)listener crop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end

# pragma restart crop callback

@interface RestartCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) NSString* cropID;
-(id) initWithManager:(APSCropManager*)manager andCropID:(NSString*)cropID;
@end

# pragma synchronize subscription

@interface DeleteSyncCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithManager:(APSCropManager*)manager crop:(APSCrop*)crop andListener:(id<APSCallback>)listener;
@end

@interface RetrieveSubscriptionsCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithManager:(APSCropManager*)manager andListener:(id<APSCallback>)listener;
@end

@interface RetrieveCropForSubscriptionsCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) NSArray* subscriptions;
-(id) initWithManager:(APSCropManager*)manager subscriptions:(NSArray*)subs andListener:(id<APSCallback>)listener;
@end

@interface RetrieveSingleCropCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSSubscription* subscription;
-(id) initWithManager:(APSCropManager*)manager subscription:(APSSubscription*)subcription andListener:(id<APSCallback>)listener;
@end

@interface InstallCropFromSubscriptionCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSSubscription* subscription;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithManager:(APSCropManager*)manager subscription:(APSSubscription*)subcription crop:(APSCrop*)crop andListener:(id<APSCallback>)listener;
@end

@interface InstallSyncCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCrop* crop;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithCrop:(APSCrop*)crop manager:(APSCropManager*)manager andListener:(id<APSCallback>)listener;
@end

#pragma update preferences
@interface APSUpdateCropsStateCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSPreferences* preferences;
-(id) initWithPreferences:(APSPreferences*)preferences andManager:(APSCropManager*)manager;
@end
