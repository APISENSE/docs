#import "APSDatabase.h"
#import "Statistic.h"
#import "APSUploadedEntry.h"
#import "APSCropLocalStatistics.h"

@interface APSStatisticsDabatase : APSDatabase
-(APSCropLocalStatistics*) retrieveCropUsage:(NSString*)slug;
-(BOOL) add:(NSString*)slug;
-(void) update:(APSCropLocalStatistics*)cropUsage;
-(BOOL) delete:(NSString*)slug;
@end