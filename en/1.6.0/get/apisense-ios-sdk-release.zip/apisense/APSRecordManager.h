#import <Foundation/Foundation.h>

#import <tolo/Tolo.h>
#import <Objection/Objection.h>
#import <UIKit/UIKit.h>

#import "APSRecord.h"
#import "APSRecordEvent.h"
#import "APSCropDatabase.h"
#import "APSStatisticsDabatase.h"
#import "APSRecordDatabase.h"
#import "APSLogger.h"
#import "APSClientRecord.h"

/**
 *  Handle data saving and export
 */
@interface APSRecordManager : NSObject

@property (nonatomic, strong) APSCropDatabase* cropDatabase;
@property (nonatomic, strong) APSClientRecord* client;
@property (nonatomic, strong) APSRecordDatabase* recordDatabase;
@property (nonatomic, strong) APSStatisticsDabatase* statisticsDatabase;
-(void) exportCrop:(NSString*)cropId withHeader:(NSDictionary*)header andTimestamp:(NSString*)timestamp;

@end

@interface SendDataToHoneycombCallback : NSObject <APSCallback>
@property (nonatomic, strong) APSRecordManager* manager;
@property (nonatomic, strong) NSString* url;
@property (nonatomic, strong) NSString* version;
@property (nonatomic, strong) NSString* slug;
-(id) initWithManager:(APSRecordManager*)manager url:(NSString*)url slug:(NSString*)slug andVersion:(NSString*)version;
@end

@interface SendFileToHoneycombCallback : NSObject <APSCallback>
@property (nonatomic, strong) NSString* filePath;
@property (nonatomic, strong) NSString* url;
-(id) initFilePath:(NSString*)filePath andUrl:(NSString*)url;
@end