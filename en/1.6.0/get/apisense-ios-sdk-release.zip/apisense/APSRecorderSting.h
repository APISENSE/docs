#import <JavaScriptCore/JSExport.h>

#import "APSSting.h"
#import "APSRecordEvent.h"
#import "APSSyncEvent.h"
#import "NSDictionary+APSNullRemover.h"

@protocol RecorderJsExports<JSExport>
- (void) save:(id)data ;
- (void) sync:(JSValue *)header;
@end

@interface APSRecorderSting : APSSting <RecorderJsExports>
@end