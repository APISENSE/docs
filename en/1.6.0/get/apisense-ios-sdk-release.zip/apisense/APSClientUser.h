#import <Foundation/Foundation.h>

#import "APSClient.h"
#import "APSCallback.h"

#import <CocoaSecurity/CocoaSecurity.h>
#import <Objection/Objection.h>

/**
 * Proxy used by APSSessionManager class
 */
@interface APSClientUser : APSClient

-(void) createBeeNamed:(NSString *)fullName WithUsername:(NSString*)username WithPassword:(NSString*)password WithEmail:(NSString*)email andListener:(id<APSCallback>)listener;
-(void) loginWithEmail:(NSString *)email password:(NSString *)password andListener:(id<APSCallback>)listener;
-(void) logoutWithToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
-(void) getProfileWithToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
@end
