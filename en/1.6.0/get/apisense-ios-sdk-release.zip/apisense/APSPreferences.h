#import "APSClient.h"
#import "APSPrivacyPreferences.h"

#import <Mantle/Mantle.h>

@interface APSPreferences : MTLModel <MTLJSONSerializing>
@property (nonatomic, strong) APSPrivacyPreferences* privacyPreferences;

/**
 *  Add sensors to disabled sensors list
 *
 *  @param sensor Sting name
 */
-(void) addDisabledSensor:(NSString*)sensor;

/**
 *  Remove sensors to disabled sensors list
 *
 *  @param sensor Sting name
 */
-(void) removeDisabledSensor:(NSString*)sensor;

@end
