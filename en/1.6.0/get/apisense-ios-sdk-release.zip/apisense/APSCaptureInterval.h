#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@interface APSCaptureInterval : MTLModel <MTLJSONSerializing>
@property (nonatomic, strong) NSNumber* begin;
@property (nonatomic, strong) NSNumber* end;
@end
