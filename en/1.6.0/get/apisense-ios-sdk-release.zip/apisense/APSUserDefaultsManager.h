#import <Foundation/Foundation.h>

#import "APSLogger.h"
#import "APSCrop.h"

@interface APSUserDefaultsManager : NSObject
@property (nonatomic, strong) NSUserDefaults* preferences;
+(id) sharedInstance;

-(NSString*) retrieveUserToken;
-(void) saveTokenToUserDefaults:(NSString*)token;
-(void) removeTokenFromUserDefaults;

-(NSArray*) retrieveActiveCrops;
-(void) saveToActiveCrop:(NSString*)cropID;
-(void) removeFromActiveCrop:(NSString*)cropID;
@end
