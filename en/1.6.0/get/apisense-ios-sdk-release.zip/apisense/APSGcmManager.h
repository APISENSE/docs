#import <Foundation/Foundation.h>
#import <Objection/Objection.h>
#import <Google/CloudMessaging.h>
#import "APSLogger.h"
#import "APSCropPushMessageHandler.h"
#import "APSPushMessageHandler.h"

@interface APSGcmManager : NSObject <UIApplicationDelegate, GGLInstanceIDDelegate, GCMReceiverDelegate>

@property (nonatomic, readonly, strong) NSString *registrationKey;
@property (nonatomic, readonly, strong) NSString *messageKey;
@property (nonatomic, readonly, strong) NSString *gcmSenderID;
@property (nonatomic, readonly, strong) NSDictionary *registrationOptions;

@property (nonatomic, strong) APSCropPushMessageHandler* cropPushMessageHandler;

- (void) subscribeToTopic:(NSString*)topic;
- (void) unsubscribeToTopic:(NSString*)topic;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error;
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo;
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))handler;
- (void)applicationDidEnterBackground:(UIApplication *)application;
- (void)applicationDidBecomeActive:(UIApplication *)application;

- (void)onTokenRefresh;
- (void)willSendDataMessageWithID:(NSString *)messageID error:(NSError *)error;
- (void)didSendDataMessageWithID:(NSString *)messageID;
- (void)didDeleteMessagesOnServer;
@end
