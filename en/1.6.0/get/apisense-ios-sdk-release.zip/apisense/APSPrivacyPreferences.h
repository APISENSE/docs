#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@interface APSPrivacyPreferences : MTLModel <MTLJSONSerializing>

/**
 *  List of the disabled sensors
 */
@property (nonatomic, strong) NSArray* disabledSensors;

/**
 *  List of the excluded capture intervals
 */
@property (nonatomic, strong) NSArray* captureIntervals;

/**
 *  List of the excluded capture areas
 */
@property (nonatomic, strong) NSArray* captureAreas;
@end
