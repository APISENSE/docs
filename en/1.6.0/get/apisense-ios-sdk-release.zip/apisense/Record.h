#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Record : NSManagedObject

@property (nonatomic, retain) NSString * cropID;
@property (nonatomic, retain) NSNumber * version;
@property (nonatomic, retain) NSString * data;
@property (nonatomic, retain) NSString * timestamp;
@property (nonatomic, retain) NSString * collectUrl;

@end
