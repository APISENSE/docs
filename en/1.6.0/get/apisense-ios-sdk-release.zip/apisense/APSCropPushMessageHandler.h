#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSCropManager.h"
#import "APSPushMessageHandler.h"

@interface APSCropPushMessageHandler : NSObject<APSPushMessageHandler>
@property (nonatomic, strong) APSCropManager* cropManager;
@end
