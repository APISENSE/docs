#import <Foundation/Foundation.h>

#import "Crop.h"
#import "APSCropGlobalStatistics.h"

#import <Mantle/Mantle.h>

@interface APSCrop : MTLModel <MTLJSONSerializing>

@property (nonatomic, strong) NSString* slug;
@property (nonatomic, strong) NSString* location;
@property (nonatomic, strong) NSString* name;
@property (nonatomic, strong) NSString* owner;
@property (nonatomic, strong) NSArray* usedStings;
@property int version;
@property (nonatomic, strong) NSString* shortDescription;
@property (nonatomic, strong) NSString* longDescription;
@property long begin;
@property long end;
@property (nonatomic, strong) APSCropGlobalStatistics* statistics;
@property BOOL isActive;

-(id) initWithCrop:(Crop*) crop;
@end