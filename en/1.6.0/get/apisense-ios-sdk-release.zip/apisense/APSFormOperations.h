@protocol APSFormOperations
-(void) show;
-(void) checkbox:(NSString*)label :(NSString*)identifier :(BOOL)mandatory :(NSString*)params,...;
@end