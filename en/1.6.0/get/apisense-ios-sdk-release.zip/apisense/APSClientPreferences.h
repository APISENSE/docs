#import "APSClient.h"
#import "APSPreferences.h"

@interface APSClientPreferences : APSClient
-(void) retrievePreferencesWithToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
-(void) savePreferences:(NSDictionary*)preferences withToken:(NSString*)userToken andListener:(id<APSCallback>)listener;
@end
