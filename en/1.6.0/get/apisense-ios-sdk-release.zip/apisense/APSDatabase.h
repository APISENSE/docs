#import <Foundation/Foundation.h>

#import "APSClientConstants.h"

#import <Objection/Objection.h>
#import <CoreData/CoreData.h>
#import "APSLogger.h"

/**
 *  Local database storage class based on CoreData framework
 */
@interface APSDatabase : NSObject

/* Core data stuff */
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

/**
 *  Save CoreData context after operation (add, delete, update..)
 *
 *  @return YES if success, NO otherwise
 */
- (BOOL)saveContextIsSuccessful;

/**
 *  @return CoreData storage directory
 */
- (NSURL *)applicationDocumentsDirectory;

@end
