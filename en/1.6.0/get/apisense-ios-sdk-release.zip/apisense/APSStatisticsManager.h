#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSStatisticsDabatase.h"
#import "APSStatisticsOperations.h"
#import "APSClientStatistics.h"
#import "APSCrop.h"

@interface APSStatisticsManager : NSObject<APSStatisticsOperations>
@property (nonatomic, strong) APSStatisticsDabatase* statisticsDatabase;
@property (strong, nonatomic) APSClientStatistics* client;
@property (nonatomic,strong) APSSession* session;

-(APSCropLocalStatistics*) getCropUsage:(APSCrop*)crop;
-(void) findGlobalStatisticsForSlug:(NSString*)slug andListener:(id<APSCallback>)listener;
@end

@interface APSRetrieveCropsGlobalStatisticsCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
-(id) initWithListener:(id<APSCallback>)listener;
@end