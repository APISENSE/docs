#import "APSCrop.h"

@protocol APSStatisticsOperations
-(APSCropLocalStatistics*) getCropUsage:(APSCrop*)crop;
@end