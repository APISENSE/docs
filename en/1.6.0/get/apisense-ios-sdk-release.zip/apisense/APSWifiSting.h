#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <UIKit/UIKit.h>
#import <SystemConfiguration/CaptiveNetwork.h>
#import <Reachability/Reachability.h>

#import "APSSting.h"
#import "APSWifiData.h"

#define STING_NAME @"Wifi"
#define STING_DESC @"Retrieve information about Wifi environment"

@protocol WifiJsExports<JSExport>

@property (nonatomic) int CONNECTED;
@property (nonatomic) int DISCONNECTED;

@property (nonatomic) int WEP;
@property (nonatomic) int WPA_PSK;

-(APSWifiData*) data;
-(BOOL) isState:(int)state;
-(BOOL) isAuthentication:(int)authentication;

-(NSString*) state;
-(NSString*) authentication;
-(NSString*) ssid;
-(NSString*) bssid;
-(id) frequency;
-(id) rssi;

-(APSStingToken*) onStateChanged:(NSString*)function;
-(APSStingToken*) onSsidChanged:(NSString*)function;
-(APSStingToken*) onScanCompleted:(NSString*)function;

@end

@interface APSWifiSting : APSSting <WifiJsExports>

@end