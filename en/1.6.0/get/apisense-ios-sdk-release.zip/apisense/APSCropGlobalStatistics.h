#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@interface APSCropGlobalStatistics : MTLModel <MTLJSONSerializing>
@property (nonatomic, strong) NSString* cropSlug;
@property (nonatomic, strong) NSNumber* numberOfSubscribers;
@property (nonatomic, strong) NSArray* dailySubscribers;
@property (nonatomic, strong) NSString* updatedAt;
@end