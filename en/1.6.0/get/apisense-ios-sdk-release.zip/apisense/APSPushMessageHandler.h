//
//  APSPushMessageHandler.h
//  sdk
//
//  Created by Spirals on 30/09/2015.
//  Copyright © 2015 Spirals. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol APSPushMessageHandler
-(void)execute:(NSString*)action target:(NSString*)target;
@end
