#import <Foundation/Foundation.h>

#import "APSCrop.h"
#import "APSSubscribedCrop.h"

#import <Mantle/Mantle.h>

/**
 *  Represents a crop with all its informations
 */
@interface APSPersistedCrop : MTLModel <MTLJSONSerializing>

@property (nonatomic, strong) NSString* slug;
@property (nonatomic, strong) NSString* cropLocation;
@property (nonatomic, strong) NSString* name;
@property (nonatomic, strong) NSString* owner;
@property (nonatomic, strong) NSData* usedStings;
@property (nonatomic) BOOL isActive;
@property NSNumber* version;
@property (nonatomic, strong) NSString* shortDescription;
@property (nonatomic, strong) NSString* longDescription;
@property long begin;
@property long end;
@property (nonatomic, strong) NSData* statistics;
@property (nonatomic, strong) NSString* subscriptionLocation;
@property (nonatomic, strong) NSString* script;
@property (nonatomic, strong) NSString* collectUrl;
@property (nonatomic, strong) NSString* dataToken;

-(id) initWithCrop:(APSCrop*)crop andSubscribedCrop:(APSSubscribedCrop*)subCrop;

@end
