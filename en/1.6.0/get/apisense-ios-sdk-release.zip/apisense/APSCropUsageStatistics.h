#import <Foundation/Foundation.h>
#import "Statistic.h"
#import "APSUploadedEntry.h"

@interface APSCropUsageStatistics : NSObject
@property (nonatomic, strong) NSString* slug;
@property (nonatomic, strong) NSNumber* toUpload;
@property (nonatomic, strong) NSNumber* totalUploaded;
@property (nonatomic, strong) NSArray* uploaded;

-(id) initWithStatistic:(Statistic*)stat;
-(void) incrementToUpload;
-(void) tracesUploaded;
@end
