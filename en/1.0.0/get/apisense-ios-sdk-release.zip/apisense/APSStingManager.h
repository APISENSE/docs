#import <Foundation/Foundation.h>
#import <Objection/Objection.h>

#import "APSScriptLibrary.h"
#import "APSSting.h"
#import "APSStings.h"
#import "APSLogger.h"

@interface APSStingManager : NSObject

@property (nonatomic, strong) NSMutableDictionary* instantiatedStings;
@property (nonatomic, strong) NSMutableDictionary* stingsForCrop;
@property (nonatomic, strong) NSMutableDictionary* stingCount;

-(APSSting<APSStingOperations>*) require:(NSString*)stingName cropId:(NSString*)cropId;
-(void) stopCrop:(NSString*)cropId;
-(NSArray*) runningStings;

@end
