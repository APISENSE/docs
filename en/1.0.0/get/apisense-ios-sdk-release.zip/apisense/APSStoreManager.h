#import <Foundation/Foundation.h>

#import "APSCallback.h"
#import "APSClientStore.h"
#import "APSCrop.h"
#import "APSStoreOperations.h"
#import "APSLogger.h"

#import <Objection/Objection.h>
#import <Mantle/Mantle.h>

/**
 *  Public class available to interact with Hive server
 */
@interface APSStoreManager : NSObject <APSStoreOperations>

@property (strong, nonatomic) APSClientStore* client;
@property (nonatomic,strong) APSSession* session;

- (void) findAllCropsWithListener:(id<APSCallback>)listener;
- (void) findAllCropsWithFilter:(NSString*)filter andListener:(id<APSCallback>)listener;
- (void) findSpecificCrop:(NSString*)cropID andListener:(id<APSCallback>)listener;
    
@end

/**
 Get crops callback
 */
@interface CropsCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
-(id) initWithListener:(id<APSCallback>)listener;
@end