#import "APSData.h"

@protocol WifiDataExports<JSExport>

@property (nonatomic, strong) NSString* state;
@property (nonatomic, strong) NSString* authentication;
@property (nonatomic, strong) NSString* ssid;
@property (nonatomic, strong) NSString* bssid;
@property (nonatomic, strong) id frequency;
@property (nonatomic, strong) id rssi;

@end

@interface APSWifiData : APSData<WifiDataExports>
-(id) initWithState:(NSString*)_state authentication:(NSString*)_authentication ssid:(NSString*)_ssid bssid:(NSString*)_bssid frequency:(id)_frequency rssi:(id)_rssi;
@end
