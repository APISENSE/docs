@protocol APSCropOperations

/**
 *  Install a crop on the device
 *
 *  @param crop     The crop to install
 *  @param listener Implements APSCallback class, returns nil on success
 */
-(void) subscribeTo:(APSCrop*)crop withListener:(id<APSCallback>)listener; // void

/**
 *  Uninstall a crop from the device
 *
 *  @param crop     The crop to uninstall
 *  @param listener Implements APSCallback class, returns nil on success
 */
-(void) unsubscribeTo:(APSCrop*)crop withListener:(id<APSCallback>)listener; // void

/**
 *  Start running a crop on the device
 *
 *  @param crop     The crop to start
 *  @param listener Implements APSCallback class, returns nil on success
 */
-(void) start:(APSCrop*)crop withListener:(id<APSCallback>)listener; // void

/**
 *  Stop running a crop on the device
 *
 *  @param crop     The crop to stop
 *  @param listener Implements APSCallback class, returns nil on success
 */
-(void) stop:(APSCrop*)crop withListener:(id<APSCallback>)listener;

/**
 *  Retrieve all crops installed on the device
 *
 *  @param listener Implements APSCallback class, returns NSArray of APSCrop on success
 */
-(void) getSubscriptionsWithListener:(id<APSCallback>)listener;

/**
 *  Return if crop is installed on the device
 *
 *  @param crop The crop to check
 *
 *  @return YES if crop is installed, NO otherwise
 */
-(BOOL) isSubscribed:(APSCrop*)crop;

/**
 *  Return if a crop is currently running on the device
 *
 *  @param crop The crop to check
 *
 *  @return YES if crop is running, NO otherwise
 */
-(BOOL) isRunning:(APSCrop*)crop;

@end