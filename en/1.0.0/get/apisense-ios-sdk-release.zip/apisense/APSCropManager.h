#import <Foundation/Foundation.h>

#import "APSCrop.h"
#import "APSClientCrop.h"
#import "APSSession.h"
#import "APSCropDatabase.h"

#import "APSCallback.h"
#import "APSClientConstants.h"

#import "APSCropOperations.h"
#import "APSExecutionHandler.h"
#import "APSExecutionHandlerFactory.h"
#import "APSLogger.h"

#import <tolo/Tolo.h>
#import <Objection/Objection.h>

/**
 Public class available to manage crops installed on the device
 */
@interface APSCropManager : NSObject <APSCropOperations>

@property (nonatomic,strong) APSClientCrop * client;
@property (nonatomic, strong) APSSession* session;
@property (nonatomic, strong) APSCropDatabase* cropDatabase;
@property (nonatomic, strong) APSExecutionHandlerFactory* executionHandlerFactory;

-(void) subscribeTo:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) unsubscribeTo:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) start:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) stop:(APSCrop*)crop withListener:(id<APSCallback>)listener;
-(void) getSubscriptionsWithListener:(id<APSCallback>)listener;

-(BOOL) isSubscribed:(APSCrop*)crop;
-(BOOL) isRunning:(APSCrop*)crop;

@end

# pragma subscribeTo callbacks declaration

@interface RequestSubscriptionUrlCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithListener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

@interface RetrieveSubscriptionCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithListener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

# pragma unsubscribeTo callbacks declaration

@interface RetrieveCropCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithListener:(id<APSCallback>)listener withCrop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end

@interface UnsubscriptionCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithListener:(id<APSCallback>)listener crop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end

@interface DeleteCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
-(id) initWithListener:(id<APSCallback>)listener andManager:(APSCropManager*)manager;
@end

@interface StopCallback : NSObject <APSCallback>
@end

# pragma start callback declaration

@interface RetrieveCropScriptCallback : NSObject <APSCallback>
@property (nonatomic, strong) id<APSCallback> listener;
@property (nonatomic, strong) APSCropManager* manager;
@property (nonatomic, strong) APSCrop* crop;
-(id) initWithListener:(id<APSCallback>)listener crop:(APSCrop*)crop andManager:(APSCropManager*)manager;
@end