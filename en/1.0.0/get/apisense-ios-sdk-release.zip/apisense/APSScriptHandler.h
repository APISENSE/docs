#import <Foundation/Foundation.h>
#import <JavaScriptCore/JSExport.h>
#import <tolo/Tolo.h>
#import <CocoaSecurity/CocoaSecurity.h>

#import "APSLogger.h"
#import "APSListenerTriggeredEvent.h"

@interface APSScriptHandler : NSObject

@property (nonatomic, strong) JSContext* executionContext;
@property (nonatomic, strong) NSString* script;
@property (nonatomic, strong) NSString* notificationName;
@property (nonatomic, strong) NSString* cropID;
@property (nonatomic, strong) NSString* functionHash;

-(id) initWithScript:(NSString*)script withNotificationName:(NSString*)name forContext:(JSContext*)context andCropID:(NSString*)cropID;

@end
