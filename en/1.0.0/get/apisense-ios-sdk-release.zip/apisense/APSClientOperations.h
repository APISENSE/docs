@protocol APSClientOperations

/**
 Execute a POST request on the Hive server
 @param request
 The request to execute
 @param parameters
 Parameters to send
 @param withListener
 APSCallback callback listener to implements
 */
- (void)executePostRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;

/**
 Execute a GET request on the Hive server
 @param request
 The request to execute
 @param parameters
 Parameters to send
 @param withListener
 APSCallback callback listener to implements
 */
- (void)executeGetRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;

/**
 Execute a PUT request on the Hive server
 @param request
 The request to execute
 @param parameters
 Parameters to send
 @param withListener
 APSCallback callback listener to implements
 */
- (void)executePutRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;

/**
 Execute a DELETE request on the Hive server
 @param request
 The request to execute
 @param parameters
 Parameters to send
 @param withListener
 APSCallback callback listener to implements
 */
- (void)executeDeleteRequest:(NSURL*)request withParameters:(NSDictionary*)parameters andListener:(id<APSCallback>)listener;

@end