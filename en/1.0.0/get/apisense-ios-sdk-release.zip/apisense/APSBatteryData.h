#import "APSData.h"

@protocol BatteryDataExports<JSExport>

@property (nonatomic, strong) NSString* state;
@property (nonatomic, strong) NSString* connector;
@property (nonatomic, strong) NSString* technology;
@property (nonatomic, strong) id level;
@property (nonatomic, strong) id temperature;
@property (nonatomic, strong) id voltage;

@end

@interface APSBatteryData : APSData<BatteryDataExports>

-(id) initWithState:(NSString*)_state connector:(NSString*)_connector technology:(NSString*)_technology level:(id)_level temperature:(id)_temperature voltage:(id)_voltage;

@end
