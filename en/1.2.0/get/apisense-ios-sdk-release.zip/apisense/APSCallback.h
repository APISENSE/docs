#import <Foundation/Foundation.h>

/**
 Apisense callback
 */
@protocol APSCallback <NSObject>

/**
 Success callback
 @param data
        Generic typed data
 */
-(void) onSuccess:(id)data;

/**
 Error callback
 */
-(void) onError:(NSError*)error;

@end
