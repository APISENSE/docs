#import "APSDatabase.h"

#import "APSCallback.h"
#import "APSCrop.h"
#import "APSSubscribedCrop.h"
#import "APSPersistedCrop.h"
#import "APSRecordInfo.h"
#import "Crop.h"
#import "APSLogger.h"

#import <Mantle/Mantle.h>

/**
 *  Handle Crop modification in local database
 */
@interface APSCropDatabase : APSDatabase

/**
 *  Install a crop on the device and notify the Hive server
 *
 *  @param crop     basic crop information
 *  @param subCrop  private crop information
 *  @param listener Returns nil if success, NSError otherwise
 */
-(void) installCrop:(APSCrop*)crop andSubscribed:(APSSubscribedCrop*)subCrop withListener:(id<APSCallback>)listener;

/**
 *  Retrieve all installed crops on the device
 *
 *  @param listener returns an NSArray of APSCrop, NSError otherwise
 */
-(void) retrieveAllWithListener:(id<APSCallback>)listener;

/**
 *  Retrieve extra information associate to crop
 *
 *  @param crop     The public crop we are looking for
 *  @param listener Returns APSSubscribedCrop associated to crop
 */
-(void) retrieveCrop:(APSCrop*)crop withListener:(id<APSCallback>)listener;


/**
 *  Retrieve a Crop based on its location
 *
 *  @param cropID   crop's location you are looking for
 *  @param listener Callback when completed, returns APSCrop associated to the crop
 */
-(void) retrieveCropWithLocation:(NSString*)cropID withListener:(id<APSCallback>)listener;

/**
 *  Retrieve an APSRecordInfo containing the url where to send data and the script version associated
 *
 *  @param cropID   The cropID associated to the data we want to send
 */
-(APSRecordInfo*) retrieveRecordInfo:(NSString*)cropID;

/**
 *  Retrieve the dataToken associated to a crop
 *
 *  @param cropID crop location
 *
 *  @return the dataToken
 */
-(NSString*) retrieveDataToken:(NSString*)cropID;

/**
 *  Remove crop from the device and notify Hive server
 *
 *  @param crop     the crop to delete
 *  @param listener returns nil if success, NSError otherwise
 */
-(void) uninstall:(APSCrop*)crop  withListener:(id<APSCallback>)listener;

/**
 *  Search in the device local database if a crop is installed
 *
 *  @param crop the crop we are looking for
 *
 *  @return YES if installed, NO otherwise
 */
-(BOOL) isInstalled:(APSCrop*)crop;

@end
