#import <Foundation/Foundation.h>

#import "APSSessionManager.h"
#import "APSStoreManager.h"
#import "APSCropManager.h"
#import "APSPreferencesManager.h"
#import "APSRecordManager.h"

#import "APSModule.h"
#import "APSDatabase.h"
#import "APSScriptLibrary.h"
#import "APSClientConstants.h"

#import "APSLogger.h"
#import "APSClientConstants.h"

#import <Objection/Objection.h>

@interface APISENSE : NSObject
@property (nonatomic, strong) APSSessionManager* sessionManager;
@property (nonatomic, strong) APSStoreManager* storeManager;
@property (nonatomic, strong) APSCropManager* cropManager;
@property (nonatomic, strong) APSPreferencesManager* preferencesManager;

/**
 *  Load extra-custom stings
 *
 *  @param module Objection module instance declaring the classes binding
 *  @param map    Mapping between the name of the sting and its implementation
 */
-(void) loadModule:(JSObjectionModule*)module withMapping:(NSDictionary*)map;

/**
 *  Add access key to see private crops from key's owner
 *
 *  @param key to add
 */
-(void) useAccessKey:(NSString*)key;

/**
 *  Generate the current version name
 *
 *  @return the version description
 */
-(NSString*) generateVersionName;
@end
