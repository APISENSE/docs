#import <Foundation/Foundation.h>
#import "APSEvent.h"

@interface APSRecordEvent : APSEvent

@property (nonatomic, strong) NSString* cropID;
@property (nonatomic, strong) NSDictionary* data;

@end
