@protocol APSBeeOperations

/**
 Create an user with the Bee status. This is the role an user gets to join an experiment
 @param fullName
        User's first and last name
 @param username
        User's pseudo used to connection
 @param password
        User's password used to connection
 @param email
        User's email, may be used to contact
 @param listener
        Implements the APSCallback class
 */
-(void) createBeeNamed:(NSString *)fullName WithUsername:(NSString*)username WithPassword:(NSString*)password WithEmail:(NSString*)email andListener:(id<APSCallback>)listener;

/**
 Connect the user to its account
 @param username
        User's pseudo
 @param password
        User's password
 @param listener
        Implements the APSCallback class
 */
-(void) loginWithEmail:(NSString*)email password:(NSString*)password andListener:(id<APSCallback>)listener;

/**
 Disconnect the current user
 @pre The user must be connected
 @param listener
        Implements the APSCallback class
 */
-(void) logoutWithListener:(id<APSCallback>)listener;

/**
 Retrieve all user's information
 @pre The user must be connected
 @param listener
        Implements the APSCallback class
 */
-(void) getProfileWithListener:(id<APSCallback>)listener;

/**
 Check if the user connected
 @return YES if connected, NO otherwise
 */
-(BOOL) isConnected;

@end